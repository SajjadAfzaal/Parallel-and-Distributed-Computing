import pandas as pd
import time
import string
from collections import Counter
from multiprocessing import Pool
import numpy as np

# Load stopwords
STOPWORDS = set([
    'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're",
    "you've", "you'll", "you'd", 'your', 'yours', 'yourself', 'yourselves', 'he',
    'him', 'his', 'himself', 'she', "she's", 'her', 'hers', 'herself', 'it', "it's",
    'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which',
    'who', 'whom', 'this', 'that', "that'll", 'these', 'those', 'am', 'is', 'are',
    'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does',
    'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until',
    'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into',
    'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down',
    'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here',
    'there', 'when', 'where', 'why', 'how', 'all', 'both', 'each', 'few', 'more', 'most',
    'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than',
    'too', 'very', 's', 't', 'can', 'will', 'just', 'don', "don't", 'should', "should've",
    'now', 'd', 'll', 'm', 'o', 're', 've', 'y', 'ain', 'aren', "aren't", 'couldn',
    "couldn't", 'didn', "didn't", 'doesn', "doesn't", 'hadn', "hadn't", 'hasn', "hasn't",
    'haven', "haven't", 'isn', "isn't", 'ma', 'mightn', "mightn't", 'mustn', "mustn't",
    'needn', "needn't", 'shan', "shan't", 'shouldn', "shouldn't", 'wasn', "wasn't",
    'weren', "weren't", 'won', "won't", 'wouldn', "wouldn't", 'br'
])

def clean_text(text):
    """Clean text by lowercasing, removing punctuation and stopwords"""
    text = text.lower()
    text = text.replace('<br />', ' ')
    text = text.translate(str.maketrans('', '', string.punctuation))
    words = [word for word in text.split() if word and word not in STOPWORDS]
    return words

def process_chunk(chunk_data):
    """Process a chunk of reviews and return word counter"""
    local_counter = Counter()
    for text in chunk_data:
        words = clean_text(str(text))
        local_counter.update(words)
    return local_counter

def parallel_analysis(df, num_workers):
    """Run parallel text analysis with specified number of workers"""
    start_time = time.perf_counter()

    # Split data into chunks
    review_column = 'review'
    reviews = df[review_column].tolist()
    chunks = np.array_split(reviews, num_workers)

    # Process in parallel
    with Pool(processes=num_workers) as pool:
        results = pool.map(process_chunk, chunks)

    # Combine results (reduction)
    final_counter = Counter()
    for counter in results:
        final_counter.update(counter)

    end_time = time.perf_counter()
    total_time = end_time - start_time

    return final_counter, total_time

def main():
    print("Starting Parallel Text Analysis...")

    # Load dataset
    print("Loading dataset...")
    df = pd.read_csv('/content/drive/MyDrive/IMDB Dataset.csv', nrows=20000)
    print(f"Loaded {len(df)} reviews\n")

    # Test different worker counts
    worker_counts = [1, 2, 4, 8]
    results = []

    print("Workers | Time (s) | Speedup | Efficiency (%)")
    print("--------|----------|---------|---------------")

    baseline_time = None

    for num_workers in worker_counts:
        counter, exec_time = parallel_analysis(df, num_workers)

        if baseline_time is None:
            baseline_time = exec_time
            speedup = 1.0
        else:
            speedup = baseline_time / exec_time

        efficiency = (speedup / num_workers) * 100

        print(f"{num_workers:^8}| {exec_time:^9.1f}| {speedup:^8.2f}x| {efficiency:^15.1f}")

        results.append({
            'workers': num_workers,
            'time': exec_time,
            'speedup': speedup,
            'efficiency': efficiency,
            'counter': counter
        })

    # Save top 20 words from best run
    best_counter = results[-1]['counter']
    top_20 = best_counter.most_common(20)

    print(f"\nTop 20 most frequent words:")
    for word, freq in top_20[:10]:
        print(f"  {word}: {freq}")

    print("\nResults saved. Analysis complete!")

if __name__ == "__main__":
    main()
