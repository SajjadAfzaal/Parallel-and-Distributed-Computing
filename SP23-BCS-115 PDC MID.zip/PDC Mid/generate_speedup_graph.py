import matplotlib.pyplot as plt
import numpy as np
import os

# Create output directory
os.makedirs('sample_output', exist_ok=True)

# Real data from your experiments
# Multiprocessing (baseline: 9.5s with 1 worker)
mp_workers = [1, 2, 4, 8]
mp_times = [9.5, 4.4, 4.5, 5.6]
mp_speedup = [mp_times[0]/t for t in mp_times]

# MPI (baseline: 4.1s sequential)
mpi_processes = [1, 2, 4]
mpi_times = [4.1, 3.6, 3.5]
mpi_speedup = [mpi_times[0]/t for t in mpi_times]

# Hybrid (baseline: 4.1s sequential)
hybrid_cores = [1, 8, 16]  # 1 (sequential), 2x4, 4x4
hybrid_times = [4.1, 6.4, 12.6]
hybrid_speedup = [hybrid_times[0]/t for t in hybrid_times]

# Create figure with two subplots
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

# Plot 1: Speedup Comparison
ax1.plot(mp_workers, mp_speedup, 'b-o', label='Multiprocessing', linewidth=2, markersize=8)
ax1.plot(mpi_processes, mpi_speedup, 'g-s', label='MPI', linewidth=2, markersize=8)
ax1.plot([1, 8, 16], hybrid_speedup, 'r-^', label='Hybrid', linewidth=2, markersize=8)
ax1.plot([1, 2, 4, 8], [1, 2, 4, 8], 'k--', label='Ideal Linear', linewidth=1.5, alpha=0.7)

ax1.set_xlabel('Number of Cores/Processes', fontsize=12)
ax1.set_ylabel('Speedup', fontsize=12)
ax1.set_title('Speedup vs Number of Cores', fontsize=14, fontweight='bold')
ax1.legend(fontsize=10, loc='upper left')
ax1.grid(True, alpha=0.3)
ax1.set_xlim(0, 9)
ax1.set_ylim(0, 5)

# Plot 2: Efficiency Comparison
mp_efficiency = [(s/w)*100 for s, w in zip(mp_speedup, mp_workers)]
mpi_efficiency = [(s/p)*100 for s, p in zip(mpi_speedup, mpi_processes)]
hybrid_efficiency = [(s/c)*100 for s, c in zip(hybrid_speedup, hybrid_cores)]

ax2.plot(mp_workers, mp_efficiency, 'b-o', label='Multiprocessing', linewidth=2, markersize=8)
ax2.plot(mpi_processes, mpi_efficiency, 'g-s', label='MPI', linewidth=2, markersize=8)
ax2.plot([1, 8, 16], hybrid_efficiency, 'r-^', label='Hybrid', linewidth=2, markersize=8)
ax2.axhline(y=100, color='k', linestyle='--', linewidth=1.5, alpha=0.7, label='100% Efficiency')

ax2.set_xlabel('Number of Cores/Processes', fontsize=12)
ax2.set_ylabel('Efficiency (%)', fontsize=12)
ax2.set_title('Parallel Efficiency vs Number of Cores', fontsize=14, fontweight='bold')
ax2.legend(fontsize=10, loc='upper right')
ax2.grid(True, alpha=0.3)
ax2.set_xlim(0, 9)
ax2.set_ylim(0, 120)

plt.tight_layout()
plt.savefig('sample_output/speedup_graph.png', dpi=300, bbox_inches='tight')
print("Graph saved to sample_output/speedup_graph.png")
plt.show()

# Print summary statistics
print("\n" + "="*60)
print("PERFORMANCE SUMMARY")
print("="*60)

print("\nMultiprocessing Performance:")
for w, t, s, e in zip(mp_workers, mp_times, mp_speedup, mp_efficiency):
    print(f"  {w} workers: {t:.1f}s, Speedup: {s:.2f}x, Efficiency: {e:.1f}%")

print("\nMPI Performance:")
for p, t, s, e in zip(mpi_processes, mpi_times, mpi_speedup, mpi_efficiency):
    print(f"  {p} processes: {t:.1f}s, Speedup: {s:.2f}x, Efficiency: {e:.1f}%")

print("\nHybrid Performance:")
labels = ["Sequential", "2 nodes × 4 threads", "4 nodes × 4 threads"]
for l, c, t, s, e in zip(labels, hybrid_cores, hybrid_times, hybrid_speedup, hybrid_efficiency):
    print(f"  {l}: {t:.1f}s, Speedup: {s:.2f}x, Efficiency: {e:.1f}%")

print("\n" + "="*60)
print("BEST CONFIGURATION: Multiprocessing with 2 workers")
print(f"  Time: 4.4s (vs 4.1s sequential)")
print(f"  Speedup: 2.15x (over multiprocessing baseline)")
print(f"  Efficiency: 107.3%")
print("="*60)