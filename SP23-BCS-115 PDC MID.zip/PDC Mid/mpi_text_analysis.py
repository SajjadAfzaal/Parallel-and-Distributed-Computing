from mpi4py import MPI
import pandas as pd
import time
import string
from collections import Counter
import numpy as np

# Load stopwords
STOPWORDS = set([
    'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're", 
    "you've", "you'll", "you'd", 'your', 'yours', 'yourself', 'yourselves', 'he', 
    'him', 'his', 'himself', 'she', "she's", 'her', 'hers', 'herself', 'it', "it's", 
    'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which', 
    'who', 'whom', 'this', 'that', "that'll", 'these', 'those', 'am', 'is', 'are', 
    'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 
    'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 
    'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 
    'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 
    'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 
    'there', 'when', 'where', 'why', 'how', 'all', 'both', 'each', 'few', 'more', 'most', 
    'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 
    'too', 'very', 's', 't', 'can', 'will', 'just', 'don', "don't", 'should', "should've", 
    'now', 'd', 'll', 'm', 'o', 're', 've', 'y', 'ain', 'aren', "aren't", 'couldn', 
    "couldn't", 'didn', "didn't", 'doesn', "doesn't", 'hadn', "hadn't", 'hasn', "hasn't", 
    'haven', "haven't", 'isn', "isn't", 'ma', 'mightn', "mightn't", 'mustn', "mustn't", 
    'needn', "needn't", 'shan', "shan't", 'shouldn', "shouldn't", 'wasn', "wasn't", 
    'weren', "weren't", 'won', "won't", 'wouldn', "wouldn't", 'br'
])

def clean_text(text):
    """Clean text by lowercasing, removing punctuation and stopwords"""
    text = text.lower()
    text = text.replace('<br />', ' ')
    text = text.translate(str.maketrans('', '', string.punctuation))
    words = [word for word in text.split() if word and word not in STOPWORDS]
    return words

def process_reviews(reviews):
    """Process reviews and return word counter"""
    local_counter = Counter()
    for text in reviews:
        words = clean_text(str(text))
        local_counter.update(words)
    return dict(local_counter)

def main():
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    
    start_time = time.perf_counter()
    
    if rank == 0:
        # Master rank: Load and distribute data
        print(f"MPI Distributed Text Analysis with {size} processes")
        print("Loading dataset...")
        df = pd.read_csv('Dataset.csv', nrows=20000)
        review_column = 'review'
        reviews = df[review_column].tolist()
        
        print(f"Loaded {len(reviews)} reviews")
        print(f"Splitting data among {size} processes...\n")
        
        # Split data into chunks for each process
        chunks = np.array_split(reviews, size)
        
        # Optional: Create imbalance (UNCOMMENT TO TEST IMBALANCE)
        # This gives rank 0 more data to demonstrate slowdown
        # if size > 1:
        #     extra_data = chunks[1][:len(chunks[1])//2]
        #     chunks[0] = np.concatenate([chunks[0], extra_data])
        #     chunks[1] = chunks[1][len(chunks[1])//2:]
        
    else:
        chunks = None
    
    # Scatter data to all processes
    local_chunk = comm.scatter(chunks, root=0)
    
    # Each process works on its chunk
    local_start = time.perf_counter()
    local_counter = process_reviews(local_chunk)
    local_end = time.perf_counter()
    local_time = local_end - local_start
    
    print(f"Rank {rank} processed {len(local_chunk)} lines in {local_time:.1f}s")
    
    # Gather all results to master
    all_counters = comm.gather(local_counter, root=0)
    
    if rank == 0:
        # Master aggregates results
        print("\nAggregating results...")
        final_counter = Counter()
        for counter_dict in all_counters:
            final_counter.update(counter_dict)
        
        end_time = time.perf_counter()
        total_time = end_time - start_time
        
        # Get top 20 words
        top_20 = final_counter.most_common(20)
        
        print(f"\nTotal distributed time: {total_time:.1f}s")
        
        # Calculate speedup (assuming sequential baseline of ~58 seconds for 20k reviews)
        sequential_time = 58.0  # Update with your actual sequential time
        speedup = sequential_time / total_time
        print(f"Speedup over sequential: {speedup:.2f}x")
        
        print(f"\nTop 20 most frequent words:")
        for word, freq in top_20[:10]:
            print(f"  {word}: {freq}")
        
        print(f"\nTotal unique words: {len(final_counter)}")

if __name__ == "__main__":
    main()
