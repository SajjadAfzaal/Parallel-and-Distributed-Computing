import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from collections import Counter
import time
import csv

# --- Configuration ---
# NOTE: In Google Colab, you will need to upload your CSV file or
# adjust this path if it's mounted from Google Drive.
FILE_PATH = '/content/drive/MyDrive/IMDB Dataset.csv'
# Updated to 'review' based on your file's column names
TEXT_COLUMN = 'review'
MAX_ROWS = 20000
TOP_N = 20
OUTPUT_FILE = 'seq_output.csv'

def initialize_nltk():
    """Ensure NLTK stopwords are downloaded (necessary for fresh Colab instances)."""
    try:
        stopwords.words('english')
    except LookupError:
        print("Downloading NLTK stopwords...")
        nltk.download('stopwords')

    # Reload stopwords after download
    return set(stopwords.words('english'))

def clean_text(text, stop_words):
    """
    Performs text cleaning: lowercasing, punctuation removal, and tokenization.
    """
    # 1. Lowercase the text
    text = str(text).lower()

    # 2. Remove punctuation and special characters (keep only letters and spaces)
    text = re.sub(r'[^a-z\s]', '', text)

    # 3. Tokenize and remove stopwords
    words = text.split()
    words = [word for word in words if word not in stop_words and len(word) > 1]

    return words

def main():
    """
    Executes the Sequential Word Frequency Analysis task and prints the summary output.
    """
    start_time = time.time()

    # 1. Initialize stopwords
    stop_words = initialize_nltk()

    try:
        # 2. Load the dataset
        print(f"Loading data from '{FILE_PATH}'...")
        # We only need the text column for this task
        df = pd.read_csv(FILE_PATH, usecols=[TEXT_COLUMN], nrows=MAX_ROWS, encoding='utf-8')
        total_rows = len(df)
    except FileNotFoundError:
        print(f"Error: The file '{FILE_PATH}' was not found. Please check the file path or upload the CSV.")
        return
    except KeyError:
        print(f"Error: Column '{TEXT_COLUMN}' not found in the CSV. Please verify the column name.")
        return
    except Exception as e:
        print(f"An unexpected error occurred during file loading: {e}")
        return

    # Initialize a global counter for all words
    word_counts = Counter()

    # Process the reviews sequentially
    print(f"Starting sequential processing of {total_rows} reviews...")

    # Iterate through the review texts
    for index, row in df.iterrows():
        review = row[TEXT_COLUMN]

        # Clean the text and get the list of words (tokens)
        words = clean_text(review, stop_words)

        # 3. Count the frequency of all words
        word_counts.update(words)

    # Calculate top N most common words
    top_words = word_counts.most_common(TOP_N)

    # Stop timer
    end_time = time.time()
    total_time = end_time - start_time

    # 4. Write top N most frequent words to seq_output.csv
    try:
        with open(OUTPUT_FILE, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            # Write header
            writer.writerow(['Word', 'Frequency'])
            # Write data
            writer.writerows(top_words)
    except Exception as e:
        print(f"Error writing to CSV file: {e}")

    # 5. Print the requested summarized output

    # Format the time output (e.g., 58.2 seconds), rounded to one decimal place
    formatted_time = f"{total_time:.1f}"

    # Format the top words output for the print summary: word(count), word(count), ...
    # We show the top 3 here to match your example's conciseness.
    top_words_summary = ", ".join([f"{word}({count})" for word, count in top_words[:3]])

    print("\n" + "="*50)
    print("ANALYSIS SUMMARY (Task 1 Output):")
    print(f"● Processed {total_rows} reviews in {formatted_time} seconds.")
    print(f"● Top words (Top 3 of {TOP_N} total): {top_words_summary}, ...")
    print(f"   (Full list of {TOP_N} words saved to '{OUTPUT_FILE}')")
    print("="*50)

if __name__ == "__main__":
    main()

