"""
Gunicorn Configuration File
Optimized for both Vertical and Horizontal Scaling

VERTICAL SCALING:
- Increase workers based on CPU cores
- Adjust worker connections
- Tune timeout values

HORIZONTAL SCALING:
- Run multiple instances behind load balancer
- Each instance runs this configuration
"""

import multiprocessing
import os

# =============================================================================
# WORKER CONFIGURATION (VERTICAL SCALING)
# =============================================================================

# Number of worker processes
# Formula: (2 x CPU cores) + 1
# Increase CPU cores = automatic worker increase
workers = int(os.environ.get('GUNICORN_WORKERS', (multiprocessing.cpu_count() * 2) + 1))

# Worker class - 'sync' for CPU-bound, 'gevent' or 'eventlet' for I/O-bound
worker_class = os.environ.get('GUNICORN_WORKER_CLASS', 'sync')

# Threads per worker (for thread-based concurrency)
threads = int(os.environ.get('GUNICORN_THREADS', 2))

# Maximum pending connections
backlog = int(os.environ.get('GUNICORN_BACKLOG', 2048))

# Maximum concurrent clients per worker (for async workers)
worker_connections = int(os.environ.get('GUNICORN_WORKER_CONNECTIONS', 1000))

# =============================================================================
# TIMEOUT CONFIGURATION
# =============================================================================

# Request timeout (seconds)
timeout = int(os.environ.get('GUNICORN_TIMEOUT', 30))

# Grace period for worker shutdown
graceful_timeout = int(os.environ.get('GUNICORN_GRACEFUL_TIMEOUT', 30))

# Keep-alive connections timeout
keepalive = int(os.environ.get('GUNICORN_KEEPALIVE', 2))

# =============================================================================
# SERVER CONFIGURATION
# =============================================================================

# Bind address
bind = os.environ.get('GUNICORN_BIND', '0.0.0.0:5000')

# Process naming
proc_name = 'scalable-flask-backend'

# =============================================================================
# LOGGING
# =============================================================================

# Access log
accesslog = os.environ.get('GUNICORN_ACCESS_LOG', '-')

# Error log
errorlog = os.environ.get('GUNICORN_ERROR_LOG', '-')

# Log level
loglevel = os.environ.get('GUNICORN_LOG_LEVEL', 'info')

# Access log format (include response time for monitoring)
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# =============================================================================
# SECURITY
# =============================================================================

# Limit request line size
limit_request_line = 4094

# Limit request fields
limit_request_fields = 100

# Limit request field size
limit_request_field_size = 8190

# =============================================================================
# HOOKS (for monitoring and scaling)
# =============================================================================

def on_starting(server):
    """Called before the master process is initialized"""
    print(f"Starting server with {workers} workers, {threads} threads each")

def worker_int(worker):
    """Called when a worker received SIGINT or SIGTERM"""
    print(f"Worker {worker.pid} interrupted")

def pre_fork(server, worker):
    """Called before a worker is forked"""
    pass

def post_fork(server, worker):
    """Called after a worker is forked"""
    print(f"Worker {worker.pid} spawned")

def pre_exec(server):
    """Called before a new master process is forked"""
    print("Server pre-exec")

def when_ready(server):
    """Called when the server is ready to receive connections"""
    print(f"Server ready. Listening on: {bind}")

def worker_abort(worker):
    """Called when a worker timeout"""
    print(f"Worker {worker.pid} aborted (timeout)")
