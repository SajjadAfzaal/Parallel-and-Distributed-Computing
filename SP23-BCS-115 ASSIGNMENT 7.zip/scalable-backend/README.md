# Scalable Flask Backend

A production-ready Flask backend demonstrating **vertical scaling**, **horizontal scaling**, and **flexible architecture** for high-performance applications.

## 🏗️ Architecture Overview

```
                    ┌─────────────────────────────────────────────────────────┐
                    │                    NGINX Load Balancer                   │
                    │              (Horizontal Scaling - Traffic Distribution) │
                    └─────────────────────────┬───────────────────────────────┘
                                              │
              ┌───────────────────────────────┼───────────────────────────────┐
              │                               │                               │
    ┌─────────▼─────────┐         ┌─────────▼─────────┐         ┌─────────▼─────────┐
    │  Flask Instance 1  │         │  Flask Instance 2  │         │  Flask Instance 3  │
    │    (Gunicorn)      │         │    (Gunicorn)      │         │    (Gunicorn)      │
    │  - 4 Workers       │         │  - 4 Workers       │         │  - 4 Workers       │
    │  - Connection Pool │         │  - Connection Pool │         │  - Connection Pool │
    └─────────┬─────────┘         └─────────┬─────────┘         └─────────┬─────────┘
              │                               │                               │
              └───────────────────────────────┼───────────────────────────────┘
                                              │
              ┌───────────────────────────────┼───────────────────────────────┐
              │                               │                               │
    ┌─────────▼─────────┐                     │                     ┌─────────▼─────────┐
    │    PostgreSQL      │                     │                     │      Redis         │
    │  (Shared Database) │◄────────────────────┘─────────────────────│  (Shared Cache)    │
    │  - Connection Pool │                                           │  - Session Store   │
    │  - Optimized Index │                                           │  - Rate Limiting   │
    └───────────────────┘                                           └───────────────────┘
```

## 📁 Project Structure

```
scalable-backend/
├── app/
│   ├── __init__.py          # Application factory
│   ├── api/
│   │   ├── products.py      # Products API (CRUD + caching)
│   │   ├── users.py         # Users API
│   │   ├── orders.py        # Orders API (transactions)
│   │   └── health.py        # Health checks (for load balancers)
│   ├── models/
│   │   └── __init__.py      # SQLAlchemy models with indexes
│   └── utils/
│       ├── pagination.py    # Efficient pagination
│       └── validators.py    # Input validation
├── config/
│   ├── __init__.py          # Base configuration
│   ├── development.py       # Development settings
│   ├── production.py        # Production settings (Redis, PostgreSQL)
│   └── testing.py           # Test settings
├── nginx/
│   └── nginx.conf           # Load balancer configuration
├── scripts/
│   ├── benchmark.py         # Performance testing
│   └── seed_data.py         # Database seeding
├── tests/
│   └── test_api.py          # API tests
├── docker-compose.yml       # Multi-container orchestration
├── Dockerfile               # Container image
├── gunicorn.conf.py         # WSGI server configuration
├── requirements.txt         # Python dependencies
├── run.py                   # Development entry point
└── wsgi.py                  # Production entry point
```

## 🚀 Quick Start

### Development Mode

```bash
# 1. Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run development server
python run.py

# 4. Seed database (optional)
python scripts/seed_data.py
```

### Production Mode (Docker)

```bash
# 1. Start all services (3 backend instances + PostgreSQL + Redis + Nginx)
docker-compose up -d

# 2. Check status
docker-compose ps

# 3. View logs
docker-compose logs -f

# 4. Scale horizontally (add more instances)
docker-compose up -d --scale backend1=1 --scale backend2=1 --scale backend3=1
```

## 📊 Scaling Features

### Vertical Scaling (Scale Up)

1. **Database Connection Pooling**
   - Configurable pool size (default: 20 connections)
   - Max overflow for burst traffic
   - Connection recycling

2. **Caching (Redis)**
   - Response caching for read-heavy endpoints
   - Configurable TTL per endpoint
   - Cache invalidation on writes

3. **Optimized Database Queries**
   - Composite indexes for common queries
   - Pagination for large datasets
   - Bulk operations for batch inserts

4. **Gunicorn Workers**
   - Formula: (2 × CPU cores) + 1
   - Configurable via environment variables

### Horizontal Scaling (Scale Out)

1. **Multiple Backend Instances**
   - Stateless application design
   - Shared database and cache
   - Docker containerization

2. **Load Balancing (Nginx)**
   - Least-connection algorithm
   - Health check-based routing
   - Automatic failover

3. **Shared State (Redis)**
   - Centralized caching
   - Rate limiting across instances
   - Session storage

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `FLASK_ENV` | Environment mode | development |
| `DATABASE_URL` | PostgreSQL connection string | sqlite:///dev.db |
| `REDIS_URL` | Redis connection string | redis://localhost:6379 |
| `GUNICORN_WORKERS` | Number of worker processes | (2 × CPU) + 1 |
| `GUNICORN_THREADS` | Threads per worker | 2 |
| `SECRET_KEY` | Application secret key | (required in production) |

## 📈 Benchmarking

```bash
# Run benchmark against local server
python scripts/benchmark.py --url http://localhost:5000 --requests 1000 --concurrency 50

# Run comparative scaling tests
python scripts/benchmark.py --compare --url http://localhost

# Test specific endpoint
python scripts/benchmark.py --endpoint /api/products/ -n 500 -c 20
```

## 🏥 Health Checks

| Endpoint | Purpose | Used By |
|----------|---------|---------|
| `/api/health/` | Basic health | Quick checks |
| `/api/health/ready` | Readiness probe | Kubernetes, load balancers |
| `/api/health/live` | Liveness probe | Container orchestrators |
| `/api/health/metrics` | System metrics | Monitoring tools |

## 🧪 Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=app --cov-report=html

# Run specific test class
pytest tests/test_api.py::TestProductsAPI -v
```

## 📚 API Endpoints

### Products
- `GET /api/products/` - List products (cached, paginated)
- `GET /api/products/<id>` - Get product
- `POST /api/products/` - Create product
- `PUT /api/products/<id>` - Update product
- `DELETE /api/products/<id>` - Delete product
- `POST /api/products/bulk` - Bulk create

### Users
- `GET /api/users/` - List users
- `GET /api/users/<id>` - Get user
- `POST /api/users/` - Create user
- `PUT /api/users/<id>` - Update user
- `GET /api/users/<id>/orders` - Get user orders

### Orders
- `GET /api/orders/` - List orders
- `GET /api/orders/<id>` - Get order
- `POST /api/orders/` - Create order
- `PUT /api/orders/<id>/status` - Update status
- `GET /api/orders/stats` - Order statistics

## 🔮 Future Scaling Plan

1. **Database Scaling**
   - Read replicas for read-heavy workloads
   - Database sharding for very large datasets

2. **Microservices**
   - Split into independent services
   - API Gateway implementation

3. **Message Queues**
   - Async task processing (Celery + RabbitMQ)
   - Event-driven architecture

4. **Kubernetes Deployment**
   - Auto-scaling based on metrics
   - Rolling deployments

## 📄 License

MIT License
