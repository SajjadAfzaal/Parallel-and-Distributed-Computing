"""
Test Suite for Scalable Flask Backend
Demonstrates testing of scalability features
"""

import pytest
import json
from app import create_app, db
from app.models import User, Product, Order

@pytest.fixture
def app():
    """Create test application"""
    app = create_app('testing')
    
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()

@pytest.fixture
def client(app):
    """Create test client"""
    return app.test_client()

@pytest.fixture
def sample_product(app):
    """Create a sample product"""
    with app.app_context():
        product = Product(
            name='Test Product',
            description='A test product',
            price=29.99,
            stock=100,
            category='Electronics'
        )
        db.session.add(product)
        db.session.commit()
        return product.id

class TestHealthEndpoints:
    """Test health check endpoints"""
    
    def test_basic_health_check(self, client):
        """Test basic health endpoint"""
        response = client.get('/api/health/')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'healthy'
        assert 'hostname' in data
    
    def test_readiness_check(self, client):
        """Test readiness probe"""
        response = client.get('/api/health/ready')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'checks' in data
        assert 'database' in data['checks']
    
    def test_liveness_check(self, client):
        """Test liveness probe"""
        response = client.get('/api/health/live')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['alive'] == True
    
    def test_metrics_endpoint(self, client):
        """Test metrics endpoint"""
        response = client.get('/api/health/metrics')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'system' in data
        assert 'process' in data

class TestProductsAPI:
    """Test products API endpoints"""
    
    def test_get_products_empty(self, client):
        """Test getting products when none exist"""
        response = client.get('/api/products/')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'items' in data
        assert 'pagination' in data
    
    def test_create_product(self, client):
        """Test creating a product"""
        response = client.post('/api/products/',
            data=json.dumps({
                'name': 'New Product',
                'price': 49.99,
                'stock': 50,
                'category': 'Books'
            }),
            content_type='application/json'
        )
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['name'] == 'New Product'
        assert data['price'] == 49.99
    
    def test_get_product(self, client, sample_product):
        """Test getting a specific product"""
        response = client.get(f'/api/products/{sample_product}')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['name'] == 'Test Product'
    
    def test_update_product(self, client, sample_product):
        """Test updating a product"""
        response = client.put(f'/api/products/{sample_product}',
            data=json.dumps({'name': 'Updated Product'}),
            content_type='application/json'
        )
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['name'] == 'Updated Product'
    
    def test_pagination(self, client, app):
        """Test pagination works correctly"""
        # Create multiple products
        with app.app_context():
            for i in range(25):
                product = Product(
                    name=f'Product {i}',
                    price=10.00,
                    stock=10
                )
                db.session.add(product)
            db.session.commit()
        
        # Test first page
        response = client.get('/api/products/?page=1&per_page=10')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert len(data['items']) == 10
        assert data['pagination']['total_items'] == 25
        assert data['pagination']['has_next'] == True
    
    def test_category_filter(self, client, app):
        """Test filtering by category"""
        with app.app_context():
            for i in range(5):
                db.session.add(Product(name=f'Electronics {i}', price=100, category='Electronics'))
                db.session.add(Product(name=f'Books {i}', price=20, category='Books'))
            db.session.commit()
        
        response = client.get('/api/products/?category=Electronics')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert all(item['category'] == 'Electronics' for item in data['items'])

class TestUsersAPI:
    """Test users API endpoints"""
    
    def test_create_user(self, client):
        """Test creating a user"""
        response = client.post('/api/users/',
            data=json.dumps({
                'username': 'testuser',
                'email': 'test@example.com',
                'password': 'securepassword123'
            }),
            content_type='application/json'
        )
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['username'] == 'testuser'
    
    def test_duplicate_username(self, client):
        """Test that duplicate usernames are rejected"""
        # Create first user
        client.post('/api/users/',
            data=json.dumps({
                'username': 'duplicate',
                'email': 'first@example.com',
                'password': 'password123'
            }),
            content_type='application/json'
        )
        
        # Try to create duplicate
        response = client.post('/api/users/',
            data=json.dumps({
                'username': 'duplicate',
                'email': 'second@example.com',
                'password': 'password123'
            }),
            content_type='application/json'
        )
        assert response.status_code == 409

class TestScalabilityFeatures:
    """Test scalability-related features"""
    
    def test_bulk_create_products(self, client):
        """Test bulk product creation"""
        products = [
            {'name': f'Bulk Product {i}', 'price': 10.00 + i}
            for i in range(10)
        ]
        
        response = client.post('/api/products/bulk',
            data=json.dumps({'products': products}),
            content_type='application/json'
        )
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['count'] == 10
    
    def test_bulk_create_limit(self, client):
        """Test bulk create respects limits"""
        products = [
            {'name': f'Product {i}', 'price': 10.00}
            for i in range(150)  # Exceeds limit of 100
        ]
        
        response = client.post('/api/products/bulk',
            data=json.dumps({'products': products}),
            content_type='application/json'
        )
        assert response.status_code == 400

if __name__ == '__main__':
    pytest.main([__file__, '-v'])
