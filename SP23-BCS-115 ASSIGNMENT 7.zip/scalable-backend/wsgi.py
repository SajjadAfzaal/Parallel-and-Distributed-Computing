"""
WSGI Entry Point
For production deployment with Gunicorn
"""

from app import create_app

# Create application instance
app = create_app('production')

if __name__ == '__main__':
    app.run()
