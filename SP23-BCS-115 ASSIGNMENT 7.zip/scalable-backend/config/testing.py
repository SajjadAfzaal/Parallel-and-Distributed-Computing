"""
Testing Configuration
Optimized for running tests with isolated database
"""

from config import BaseConfig

class TestingConfig(BaseConfig):
    """Testing configuration"""
    
    TESTING = True
    DEBUG = True
    
    # In-memory SQLite for fast tests
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    
    # Disable caching during tests
    CACHE_TYPE = 'NullCache'
    
    # Disable rate limiting during tests
    RATELIMIT_ENABLED = False
    
    # Minimal connection pool
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 1,
        'max_overflow': 0,
    }
