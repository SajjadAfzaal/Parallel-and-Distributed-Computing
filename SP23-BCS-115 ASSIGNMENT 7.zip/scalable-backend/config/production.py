"""
Production Configuration
Optimized for scalability with PostgreSQL and Redis
"""

import os
from config import BaseConfig

class ProductionConfig(BaseConfig):
    """Production configuration with full scalability features"""
    
    DEBUG = False
    
    # PostgreSQL for production (supports high concurrency)
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL',
        'postgresql://user:password@localhost:5432/production_db'
    )
    
    # Enhanced connection pooling for vertical scaling
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 20,           # More persistent connections
        'pool_recycle': 1800,      # Recycle every 30 minutes
        'pool_pre_ping': True,     # Health check connections
        'max_overflow': 40,        # Up to 60 total connections
        'pool_timeout': 30,
        'echo_pool': False,        # Disable pool logging in production
    }
    
    # Redis caching for horizontal scaling
    CACHE_TYPE = 'RedisCache'
    CACHE_REDIS_URL = os.environ.get('REDIS_URL', 'redis://localhost:6379/0')
    CACHE_DEFAULT_TIMEOUT = 600
    CACHE_KEY_PREFIX = 'app_cache_'
    
    # Redis-based rate limiting (shared across instances)
    RATELIMIT_STORAGE_URL = os.environ.get('REDIS_URL', 'redis://localhost:6379/1')
    
    # Security settings
    SECRET_KEY = os.environ.get('SECRET_KEY')
    
    # Session configuration for horizontal scaling
    SESSION_TYPE = 'redis'
    SESSION_REDIS = os.environ.get('REDIS_URL', 'redis://localhost:6379/2')
    
    # Optimized JSON
    JSON_SORT_KEYS = False
    JSONIFY_PRETTYPRINT_REGULAR = False
