"""
Base Configuration - Common settings for all environments
Designed for scalability and flexibility
"""

import os

class BaseConfig:
    """Base configuration with common settings"""
    
    # Security
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # Database - Using SQLAlchemy connection pooling for vertical scaling
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Connection Pool Settings (Vertical Scaling)
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 10,           # Number of persistent connections
        'pool_recycle': 3600,      # Recycle connections after 1 hour
        'pool_pre_ping': True,     # Verify connections before use
        'max_overflow': 20,        # Additional connections when pool is full
        'pool_timeout': 30,        # Timeout waiting for connection
    }
    
    # Caching Configuration (Vertical Scaling - In-Memory)
    CACHE_TYPE = 'SimpleCache'
    CACHE_DEFAULT_TIMEOUT = 300
    
    # Rate Limiting
    RATELIMIT_STORAGE_URL = "memory://"
    RATELIMIT_STRATEGY = "fixed-window"
    
    # Pagination defaults
    DEFAULT_PAGE_SIZE = 20
    MAX_PAGE_SIZE = 100
    
    # JSON Settings
    JSON_SORT_KEYS = False
    JSONIFY_PRETTYPRINT_REGULAR = False
