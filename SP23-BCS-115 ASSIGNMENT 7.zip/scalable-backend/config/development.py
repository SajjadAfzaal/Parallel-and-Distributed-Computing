"""
Development Configuration
Optimized for local development with SQLite
"""

from config import BaseConfig

class DevelopmentConfig(BaseConfig):
    """Development configuration"""
    
    DEBUG = True
    
    # SQLite for development (easy setup)
    SQLALCHEMY_DATABASE_URI = 'sqlite:///dev_database.db'
    
    # Simple in-memory cache for development
    CACHE_TYPE = 'SimpleCache'
    CACHE_DEFAULT_TIMEOUT = 60
    
    # Lower connection pool for development
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 5,
        'pool_recycle': 1800,
        'pool_pre_ping': True,
        'max_overflow': 5,
    }
