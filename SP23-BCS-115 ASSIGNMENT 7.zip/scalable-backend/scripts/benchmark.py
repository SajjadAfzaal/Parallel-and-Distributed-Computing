#!/usr/bin/env python3
"""
Benchmark Script for Scalability Testing
Measures performance improvements from vertical and horizontal scaling

Usage:
    python scripts/benchmark.py --url http://localhost:5000 --requests 100 --concurrency 10
"""

import argparse
import time
import statistics
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from dataclasses import dataclass
from typing import List
import sys

@dataclass
class BenchmarkResult:
    """Container for benchmark results"""
    total_requests: int
    successful_requests: int
    failed_requests: int
    total_time: float
    avg_response_time: float
    min_response_time: float
    max_response_time: float
    median_response_time: float
    std_dev: float
    requests_per_second: float
    percentile_95: float
    percentile_99: float

def make_request(url: str, timeout: int = 30) -> tuple:
    """Make a single request and return response time"""
    start = time.time()
    try:
        response = requests.get(url, timeout=timeout)
        elapsed = time.time() - start
        return (elapsed, response.status_code == 200)
    except Exception as e:
        elapsed = time.time() - start
        return (elapsed, False)

def run_benchmark(url: str, num_requests: int, concurrency: int) -> BenchmarkResult:
    """Run benchmark with specified parameters"""
    print(f"\n{'='*60}")
    print(f"BENCHMARK CONFIGURATION")
    print(f"{'='*60}")
    print(f"URL: {url}")
    print(f"Total Requests: {num_requests}")
    print(f"Concurrency Level: {concurrency}")
    print(f"{'='*60}\n")
    
    response_times: List[float] = []
    successful = 0
    failed = 0
    
    start_time = time.time()
    
    with ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = [executor.submit(make_request, url) for _ in range(num_requests)]
        
        completed = 0
        for future in as_completed(futures):
            elapsed, success = future.result()
            response_times.append(elapsed)
            if success:
                successful += 1
            else:
                failed += 1
            
            completed += 1
            if completed % 100 == 0:
                print(f"Progress: {completed}/{num_requests} requests completed...")
    
    total_time = time.time() - start_time
    
    # Calculate statistics
    sorted_times = sorted(response_times)
    
    result = BenchmarkResult(
        total_requests=num_requests,
        successful_requests=successful,
        failed_requests=failed,
        total_time=total_time,
        avg_response_time=statistics.mean(response_times),
        min_response_time=min(response_times),
        max_response_time=max(response_times),
        median_response_time=statistics.median(response_times),
        std_dev=statistics.stdev(response_times) if len(response_times) > 1 else 0,
        requests_per_second=num_requests / total_time,
        percentile_95=sorted_times[int(len(sorted_times) * 0.95)],
        percentile_99=sorted_times[int(len(sorted_times) * 0.99)]
    )
    
    return result

def print_results(result: BenchmarkResult):
    """Print benchmark results in a formatted way"""
    print(f"\n{'='*60}")
    print(f"BENCHMARK RESULTS")
    print(f"{'='*60}")
    print(f"\n📊 Request Statistics:")
    print(f"   Total Requests:      {result.total_requests}")
    print(f"   Successful:          {result.successful_requests} ({result.successful_requests/result.total_requests*100:.1f}%)")
    print(f"   Failed:              {result.failed_requests} ({result.failed_requests/result.total_requests*100:.1f}%)")
    
    print(f"\n⏱️  Timing Statistics:")
    print(f"   Total Time:          {result.total_time:.2f} seconds")
    print(f"   Requests/Second:     {result.requests_per_second:.2f}")
    
    print(f"\n📈 Response Time (seconds):")
    print(f"   Average:             {result.avg_response_time:.4f}")
    print(f"   Minimum:             {result.min_response_time:.4f}")
    print(f"   Maximum:             {result.max_response_time:.4f}")
    print(f"   Median:              {result.median_response_time:.4f}")
    print(f"   Std Deviation:       {result.std_dev:.4f}")
    print(f"   95th Percentile:     {result.percentile_95:.4f}")
    print(f"   99th Percentile:     {result.percentile_99:.4f}")
    
    print(f"\n{'='*60}\n")

def compare_scaling(base_url: str):
    """
    Run comparative benchmarks to demonstrate scaling improvements
    """
    print("\n" + "="*60)
    print("SCALING COMPARISON TEST")
    print("="*60)
    
    # Test endpoints
    endpoints = [
        ("/api/health/", "Health Check (Simple)"),
        ("/api/products/", "Products List (Cached)"),
        ("/api/health/metrics", "Metrics (System Info)")
    ]
    
    results = {}
    
    for endpoint, name in endpoints:
        url = f"{base_url}{endpoint}"
        print(f"\n🔄 Testing: {name}")
        print(f"   Endpoint: {endpoint}")
        
        # Run benchmarks with increasing concurrency
        for concurrency in [1, 5, 10]:
            result = run_benchmark(url, num_requests=50, concurrency=concurrency)
            key = f"{name} (c={concurrency})"
            results[key] = result
            print(f"   Concurrency {concurrency}: {result.requests_per_second:.2f} req/s, "
                  f"avg: {result.avg_response_time*1000:.1f}ms")
    
    # Summary
    print("\n" + "="*60)
    print("SCALING SUMMARY")
    print("="*60)
    print("\n📊 Requests per Second by Concurrency Level:\n")
    print(f"{'Endpoint':<35} {'c=1':>10} {'c=5':>10} {'c=10':>10} {'Scaling':>10}")
    print("-" * 75)
    
    for endpoint, name in endpoints:
        c1 = results.get(f"{name} (c=1)")
        c5 = results.get(f"{name} (c=5)")
        c10 = results.get(f"{name} (c=10)")
        
        if c1 and c10:
            scaling_factor = c10.requests_per_second / c1.requests_per_second
            print(f"{name:<35} {c1.requests_per_second:>10.1f} {c5.requests_per_second:>10.1f} "
                  f"{c10.requests_per_second:>10.1f} {scaling_factor:>9.1f}x")
    
    print("\n" + "="*60 + "\n")
    
    return results

def main():
    parser = argparse.ArgumentParser(description='Benchmark Scalable Flask Backend')
    parser.add_argument('--url', default='http://localhost:5000',
                       help='Base URL of the server')
    parser.add_argument('--requests', '-n', type=int, default=100,
                       help='Number of requests to make')
    parser.add_argument('--concurrency', '-c', type=int, default=10,
                       help='Number of concurrent requests')
    parser.add_argument('--endpoint', '-e', default='/api/health/',
                       help='API endpoint to test')
    parser.add_argument('--compare', action='store_true',
                       help='Run comparative scaling tests')
    
    args = parser.parse_args()
    
    if args.compare:
        compare_scaling(args.url)
    else:
        full_url = f"{args.url}{args.endpoint}"
        result = run_benchmark(full_url, args.requests, args.concurrency)
        print_results(result)
        
        # Output JSON for automated processing
        print("\n📄 JSON Output:")
        print(json.dumps({
            'total_requests': result.total_requests,
            'successful_requests': result.successful_requests,
            'failed_requests': result.failed_requests,
            'total_time': result.total_time,
            'requests_per_second': result.requests_per_second,
            'avg_response_time_ms': result.avg_response_time * 1000,
            'p95_response_time_ms': result.percentile_95 * 1000,
            'p99_response_time_ms': result.percentile_99 * 1000
        }, indent=2))

if __name__ == '__main__':
    main()
