#!/usr/bin/env python3
"""
Database Seed Script
Populates the database with sample data for testing
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app, db
from app.models import User, Product, Order, OrderItem
from werkzeug.security import generate_password_hash
import random
from decimal import Decimal

def seed_database():
    """Seed the database with sample data"""
    app = create_app('development')
    
    with app.app_context():
        print("🗑️  Clearing existing data...")
        OrderItem.query.delete()
        Order.query.delete()
        Product.query.delete()
        User.query.delete()
        db.session.commit()
        
        print("👥 Creating users...")
        users = []
        for i in range(1, 51):
            user = User(
                username=f'user{i}',
                email=f'user{i}@example.com',
                password_hash=generate_password_hash('password123'),
                is_active=True
            )
            users.append(user)
            db.session.add(user)
        
        db.session.commit()
        print(f"   Created {len(users)} users")
        
        print("📦 Creating products...")
        categories = ['Electronics', 'Clothing', 'Books', 'Home & Garden', 'Sports', 'Toys']
        products = []
        
        product_names = [
            'Wireless Headphones', 'Smart Watch', 'Laptop Stand', 'USB-C Hub',
            'Mechanical Keyboard', 'Gaming Mouse', 'Monitor Light', 'Webcam HD',
            'Bluetooth Speaker', 'Power Bank', 'Phone Case', 'Screen Protector',
            'Running Shoes', 'Yoga Mat', 'Water Bottle', 'Fitness Tracker',
            'Backpack', 'Desk Organizer', 'LED Lamp', 'Coffee Mug',
            'Notebook Set', 'Pen Collection', 'Wall Art', 'Plant Pot',
            'Kitchen Scale', 'Timer Clock', 'Cable Organizer', 'Mouse Pad',
            'Desk Mat', 'Monitor Arm'
        ]
        
        for i, name in enumerate(product_names, 1):
            product = Product(
                name=name,
                description=f'High-quality {name.lower()} for everyday use.',
                price=Decimal(str(round(random.uniform(9.99, 299.99), 2))),
                stock=random.randint(10, 500),
                category=random.choice(categories),
                is_active=True
            )
            products.append(product)
            db.session.add(product)
        
        db.session.commit()
        print(f"   Created {len(products)} products")
        
        print("🛒 Creating orders...")
        statuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered']
        orders_created = 0
        
        for user in users[:30]:  # Create orders for first 30 users
            num_orders = random.randint(1, 5)
            
            for _ in range(num_orders):
                # Select random products for this order
                order_products = random.sample(products, random.randint(1, 4))
                
                order = Order(
                    user_id=user.id,
                    total_amount=Decimal('0'),
                    status=random.choice(statuses)
                )
                db.session.add(order)
                db.session.flush()
                
                total = Decimal('0')
                for product in order_products:
                    quantity = random.randint(1, 3)
                    item = OrderItem(
                        order_id=order.id,
                        product_id=product.id,
                        quantity=quantity,
                        unit_price=product.price
                    )
                    db.session.add(item)
                    total += product.price * quantity
                
                order.total_amount = total
                orders_created += 1
        
        db.session.commit()
        print(f"   Created {orders_created} orders")
        
        print("\n✅ Database seeded successfully!")
        print(f"\n📊 Summary:")
        print(f"   Users: {User.query.count()}")
        print(f"   Products: {Product.query.count()}")
        print(f"   Orders: {Order.query.count()}")
        print(f"   Order Items: {OrderItem.query.count()}")

if __name__ == '__main__':
    seed_database()
