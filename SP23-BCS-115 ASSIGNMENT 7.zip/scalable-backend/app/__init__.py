"""
Scalable Flask Backend Application
Designed for vertical and horizontal scaling with modular architecture
"""

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_caching import Cache
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import os
import logging

# Initialize extensions (not bound to app yet - for flexibility)
db = SQLAlchemy()
cache = Cache()
limiter = Limiter(key_func=get_remote_address, default_limits=["200 per day", "50 per hour"])

def create_app(config_name=None):
    """
    Application Factory Pattern - Essential for horizontal scaling
    Each worker process gets its own app instance
    """
    app = Flask(__name__)
    
    # Load configuration based on environment
    config_name = config_name or os.environ.get('FLASK_ENV', 'development')
    
    if config_name == 'production':
        from config.production import ProductionConfig
        app.config.from_object(ProductionConfig)
    elif config_name == 'testing':
        from config.testing import TestingConfig
        app.config.from_object(TestingConfig)
    else:
        from config.development import DevelopmentConfig
        app.config.from_object(DevelopmentConfig)
    
    # Initialize extensions with app
    db.init_app(app)
    cache.init_app(app)
    limiter.init_app(app)
    
    # Configure logging for production
    if not app.debug:
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    
    # Register blueprints (modular API design)
    from app.api.products import products_bp
    from app.api.users import users_bp
    from app.api.orders import orders_bp
    from app.api.health import health_bp
    
    app.register_blueprint(products_bp, url_prefix='/api/products')
    app.register_blueprint(users_bp, url_prefix='/api/users')
    app.register_blueprint(orders_bp, url_prefix='/api/orders')
    app.register_blueprint(health_bp, url_prefix='/api/health')
    
    # Create database tables
    with app.app_context():
        db.create_all()
    
    return app
