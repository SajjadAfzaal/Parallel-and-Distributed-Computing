"""
Health Check API Blueprint
Essential for load balancers and horizontal scaling
"""

from flask import Blueprint, jsonify
from app import db, cache
import os
import psutil
import socket
from datetime import datetime

health_bp = Blueprint('health', __name__)

@health_bp.route('/', methods=['GET'])
def health_check():
    """
    Basic health check endpoint
    Used by load balancers to verify instance availability
    """
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'hostname': socket.gethostname()
    })

@health_bp.route('/ready', methods=['GET'])
def readiness_check():
    """
    Readiness probe - checks if all dependencies are ready
    Used by orchestrators (Kubernetes, Docker Swarm) to determine
    if the instance can receive traffic
    """
    checks = {
        'database': check_database(),
        'cache': check_cache()
    }
    
    all_healthy = all(c['healthy'] for c in checks.values())
    
    response = {
        'ready': all_healthy,
        'timestamp': datetime.utcnow().isoformat(),
        'hostname': socket.gethostname(),
        'checks': checks
    }
    
    status_code = 200 if all_healthy else 503
    return jsonify(response), status_code

@health_bp.route('/live', methods=['GET'])
def liveness_check():
    """
    Liveness probe - checks if the application is running
    Used to determine if the instance should be restarted
    """
    return jsonify({
        'alive': True,
        'timestamp': datetime.utcnow().isoformat(),
        'hostname': socket.gethostname(),
        'pid': os.getpid()
    })

@health_bp.route('/metrics', methods=['GET'])
def get_metrics():
    """
    System metrics endpoint
    Useful for monitoring and auto-scaling decisions
    """
    process = psutil.Process(os.getpid())
    
    return jsonify({
        'timestamp': datetime.utcnow().isoformat(),
        'hostname': socket.gethostname(),
        'pid': os.getpid(),
        'system': {
            'cpu_percent': psutil.cpu_percent(interval=0.1),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_percent': psutil.disk_usage('/').percent
        },
        'process': {
            'cpu_percent': process.cpu_percent(),
            'memory_mb': process.memory_info().rss / 1024 / 1024,
            'threads': process.num_threads(),
            'open_files': len(process.open_files())
        }
    })

@health_bp.route('/info', methods=['GET'])
def get_info():
    """
    Application info endpoint
    Shows instance details for debugging distributed systems
    """
    return jsonify({
        'app_name': 'Scalable Flask Backend',
        'version': '1.0.0',
        'hostname': socket.gethostname(),
        'worker_id': os.getpid(),
        'environment': os.environ.get('FLASK_ENV', 'development'),
        'timestamp': datetime.utcnow().isoformat()
    })

def check_database():
    """Check database connectivity"""
    try:
        db.session.execute(db.text('SELECT 1'))
        return {'healthy': True, 'message': 'Database connection OK'}
    except Exception as e:
        return {'healthy': False, 'message': str(e)}

def check_cache():
    """Check cache connectivity"""
    try:
        # Try to set and get a test value
        cache.set('health_check', 'ok', timeout=10)
        result = cache.get('health_check')
        if result == 'ok':
            return {'healthy': True, 'message': 'Cache connection OK'}
        else:
            return {'healthy': False, 'message': 'Cache read/write failed'}
    except Exception as e:
        return {'healthy': False, 'message': str(e)}
