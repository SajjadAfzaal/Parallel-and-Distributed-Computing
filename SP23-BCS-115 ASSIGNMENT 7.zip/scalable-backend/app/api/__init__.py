"""
API Blueprints
"""
from app.api.products import products_bp
from app.api.users import users_bp
from app.api.orders import orders_bp
from app.api.health import health_bp

__all__ = ['products_bp', 'users_bp', 'orders_bp', 'health_bp']
