"""
Users API Blueprint
Implements user management with security and scalability features
"""

from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, cache, limiter
from app.models import User
from app.utils.pagination import paginate_query

users_bp = Blueprint('users', __name__)

@users_bp.route('/', methods=['GET'])
@cache.cached(timeout=30, query_string=True)
def get_users():
    """Get all users with pagination"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    is_active = request.args.get('is_active', type=bool)
    
    query = User.query
    
    if is_active is not None:
        query = query.filter(User.is_active == is_active)
    
    query = query.order_by(User.created_at.desc())
    
    result = paginate_query(query, page, per_page)
    
    return jsonify(result)

@users_bp.route('/<int:user_id>', methods=['GET'])
@cache.cached(timeout=60)
def get_user(user_id):
    """Get single user by ID"""
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())

@users_bp.route('/', methods=['POST'])
@limiter.limit("5 per minute")
def create_user():
    """Create a new user"""
    data = request.get_json()
    
    # Validation
    required_fields = ['username', 'email', 'password']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400
    
    # Check for existing user
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'error': 'Username already exists'}), 409
    
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'error': 'Email already exists'}), 409
    
    user = User(
        username=data['username'],
        email=data['email'],
        password_hash=generate_password_hash(data['password'])
    )
    
    db.session.add(user)
    db.session.commit()
    
    # Invalidate cache
    cache.delete_memoized(get_users)
    
    return jsonify(user.to_dict()), 201

@users_bp.route('/<int:user_id>', methods=['PUT'])
@limiter.limit("10 per minute")
def update_user(user_id):
    """Update user details"""
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    if 'email' in data:
        existing = User.query.filter_by(email=data['email']).first()
        if existing and existing.id != user_id:
            return jsonify({'error': 'Email already in use'}), 409
        user.email = data['email']
    
    if 'password' in data:
        user.password_hash = generate_password_hash(data['password'])
    
    if 'is_active' in data:
        user.is_active = data['is_active']
    
    db.session.commit()
    
    # Invalidate cache
    cache.delete_memoized(get_user, user_id)
    cache.delete_memoized(get_users)
    
    return jsonify(user.to_dict())

@users_bp.route('/<int:user_id>', methods=['DELETE'])
@limiter.limit("3 per minute")
def delete_user(user_id):
    """Soft delete user (deactivate)"""
    user = User.query.get_or_404(user_id)
    user.is_active = False
    db.session.commit()
    
    # Invalidate cache
    cache.delete_memoized(get_user, user_id)
    cache.delete_memoized(get_users)
    
    return jsonify({'message': 'User deactivated successfully'})

@users_bp.route('/<int:user_id>/orders', methods=['GET'])
@cache.cached(timeout=30, query_string=True)
def get_user_orders(user_id):
    """Get orders for a specific user"""
    user = User.query.get_or_404(user_id)
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    result = paginate_query(user.orders, page, per_page)
    
    return jsonify(result)
