"""
Products API Blueprint
Implements caching, pagination, and optimized queries for scalability
"""

from flask import Blueprint, request, jsonify
from app import db, cache, limiter
from app.models import Product
from app.utils.pagination import paginate_query
from app.utils.validators import validate_product_data

products_bp = Blueprint('products', __name__)

@products_bp.route('/', methods=['GET'])
@cache.cached(timeout=60, query_string=True)  # Cache with query params
def get_products():
    """
    Get all products with pagination and filtering
    Cached for 60 seconds to reduce database load (Vertical Scaling)
    """
    # Query parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    category = request.args.get('category')
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    in_stock = request.args.get('in_stock', type=bool)
    
    # Build optimized query using indexes
    query = Product.query.filter(Product.is_active == True)
    
    if category:
        query = query.filter(Product.category == category)
    if min_price is not None:
        query = query.filter(Product.price >= min_price)
    if max_price is not None:
        query = query.filter(Product.price <= max_price)
    if in_stock:
        query = query.filter(Product.stock > 0)
    
    # Order by id for consistent pagination
    query = query.order_by(Product.id)
    
    # Paginate results
    result = paginate_query(query, page, per_page)
    
    return jsonify(result)

@products_bp.route('/<int:product_id>', methods=['GET'])
@cache.cached(timeout=120)  # Cache individual products longer
def get_product(product_id):
    """Get single product by ID - cached for 2 minutes"""
    product = Product.query.get_or_404(product_id)
    return jsonify(product.to_dict())

@products_bp.route('/', methods=['POST'])
@limiter.limit("10 per minute")  # Rate limit writes
def create_product():
    """Create a new product"""
    data = request.get_json()
    
    # Validate input
    errors = validate_product_data(data)
    if errors:
        return jsonify({'errors': errors}), 400
    
    product = Product(
        name=data['name'],
        description=data.get('description', ''),
        price=data['price'],
        stock=data.get('stock', 0),
        category=data.get('category')
    )
    
    db.session.add(product)
    db.session.commit()
    
    # Invalidate cache for product listings
    cache.delete_memoized(get_products)
    
    return jsonify(product.to_dict()), 201

@products_bp.route('/<int:product_id>', methods=['PUT'])
@limiter.limit("20 per minute")
def update_product(product_id):
    """Update an existing product"""
    product = Product.query.get_or_404(product_id)
    data = request.get_json()
    
    # Update fields
    if 'name' in data:
        product.name = data['name']
    if 'description' in data:
        product.description = data['description']
    if 'price' in data:
        product.price = data['price']
    if 'stock' in data:
        product.stock = data['stock']
    if 'category' in data:
        product.category = data['category']
    if 'is_active' in data:
        product.is_active = data['is_active']
    
    db.session.commit()
    
    # Invalidate specific cache entries
    cache.delete_memoized(get_product, product_id)
    cache.delete_memoized(get_products)
    
    return jsonify(product.to_dict())

@products_bp.route('/<int:product_id>', methods=['DELETE'])
@limiter.limit("5 per minute")
def delete_product(product_id):
    """Soft delete a product (set inactive)"""
    product = Product.query.get_or_404(product_id)
    product.is_active = False
    db.session.commit()
    
    # Invalidate cache
    cache.delete_memoized(get_product, product_id)
    cache.delete_memoized(get_products)
    
    return jsonify({'message': 'Product deleted successfully'})

@products_bp.route('/bulk', methods=['POST'])
@limiter.limit("5 per minute")
def bulk_create_products():
    """
    Bulk create products - optimized for batch inserts
    Demonstrates efficient database operations for scalability
    """
    data = request.get_json()
    products_data = data.get('products', [])
    
    if not products_data:
        return jsonify({'error': 'No products provided'}), 400
    
    if len(products_data) > 100:
        return jsonify({'error': 'Maximum 100 products per batch'}), 400
    
    products = []
    for item in products_data:
        product = Product(
            name=item['name'],
            description=item.get('description', ''),
            price=item['price'],
            stock=item.get('stock', 0),
            category=item.get('category')
        )
        products.append(product)
    
    # Bulk insert for better performance
    db.session.bulk_save_objects(products)
    db.session.commit()
    
    # Invalidate cache
    cache.delete_memoized(get_products)
    
    return jsonify({
        'message': f'{len(products)} products created successfully',
        'count': len(products)
    }), 201

@products_bp.route('/categories', methods=['GET'])
@cache.cached(timeout=300)  # Cache categories for 5 minutes
def get_categories():
    """Get all unique product categories"""
    categories = db.session.query(Product.category).distinct().all()
    return jsonify([c[0] for c in categories if c[0]])
