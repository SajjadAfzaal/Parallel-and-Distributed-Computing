"""
Orders API Blueprint
Implements order management with transaction handling
"""

from flask import Blueprint, request, jsonify
from app import db, cache, limiter
from app.models import Order, OrderItem, Product, User
from app.utils.pagination import paginate_query
from decimal import Decimal

orders_bp = Blueprint('orders', __name__)

@orders_bp.route('/', methods=['GET'])
@cache.cached(timeout=30, query_string=True)
def get_orders():
    """Get all orders with pagination and filtering"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status')
    user_id = request.args.get('user_id', type=int)
    
    query = Order.query
    
    if status:
        query = query.filter(Order.status == status)
    if user_id:
        query = query.filter(Order.user_id == user_id)
    
    query = query.order_by(Order.created_at.desc())
    
    result = paginate_query(query, page, per_page)
    
    return jsonify(result)

@orders_bp.route('/<int:order_id>', methods=['GET'])
@cache.cached(timeout=60)
def get_order(order_id):
    """Get single order with items"""
    order = Order.query.get_or_404(order_id)
    return jsonify(order.to_dict())

@orders_bp.route('/', methods=['POST'])
@limiter.limit("20 per minute")
def create_order():
    """
    Create a new order with items
    Uses database transactions for data integrity
    """
    data = request.get_json()
    
    # Validate user
    user_id = data.get('user_id')
    if not user_id:
        return jsonify({'error': 'user_id is required'}), 400
    
    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    items_data = data.get('items', [])
    if not items_data:
        return jsonify({'error': 'Order must have at least one item'}), 400
    
    try:
        # Start transaction
        total_amount = Decimal('0')
        order_items = []
        
        for item in items_data:
            product = Product.query.get(item['product_id'])
            if not product:
                return jsonify({'error': f'Product {item["product_id"]} not found'}), 404
            
            if product.stock < item['quantity']:
                return jsonify({
                    'error': f'Insufficient stock for product {product.name}'
                }), 400
            
            # Calculate item total
            item_total = product.price * item['quantity']
            total_amount += item_total
            
            # Update stock
            product.stock -= item['quantity']
            
            # Create order item
            order_item = OrderItem(
                product_id=product.id,
                quantity=item['quantity'],
                unit_price=product.price
            )
            order_items.append(order_item)
        
        # Create order
        order = Order(
            user_id=user_id,
            total_amount=total_amount,
            status='pending'
        )
        db.session.add(order)
        db.session.flush()  # Get order ID
        
        # Add items to order
        for order_item in order_items:
            order_item.order_id = order.id
            db.session.add(order_item)
        
        db.session.commit()
        
        # Invalidate caches
        cache.delete_memoized(get_orders)
        
        return jsonify(order.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@orders_bp.route('/<int:order_id>/status', methods=['PUT'])
@limiter.limit("30 per minute")
def update_order_status(order_id):
    """Update order status"""
    order = Order.query.get_or_404(order_id)
    data = request.get_json()
    
    valid_statuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled']
    new_status = data.get('status')
    
    if new_status not in valid_statuses:
        return jsonify({'error': f'Invalid status. Must be one of: {valid_statuses}'}), 400
    
    # Handle cancellation - restore stock
    if new_status == 'cancelled' and order.status != 'cancelled':
        for item in order.items:
            product = Product.query.get(item.product_id)
            if product:
                product.stock += item.quantity
    
    order.status = new_status
    db.session.commit()
    
    # Invalidate cache
    cache.delete_memoized(get_order, order_id)
    cache.delete_memoized(get_orders)
    
    return jsonify(order.to_dict())

@orders_bp.route('/stats', methods=['GET'])
@cache.cached(timeout=120)
def get_order_stats():
    """Get order statistics - cached for performance"""
    from sqlalchemy import func
    
    stats = db.session.query(
        Order.status,
        func.count(Order.id).label('count'),
        func.sum(Order.total_amount).label('total')
    ).group_by(Order.status).all()
    
    return jsonify([{
        'status': s.status,
        'count': s.count,
        'total': float(s.total) if s.total else 0
    } for s in stats])
