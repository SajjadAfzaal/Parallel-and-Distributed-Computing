"""
Validation Utilities
Input validation for API endpoints
"""

def validate_product_data(data):
    """Validate product data for creation/update"""
    errors = []
    
    if not data:
        return ['Request body is required']
    
    # Required fields for creation
    if 'name' not in data:
        errors.append('name is required')
    elif not data['name'] or len(data['name']) > 200:
        errors.append('name must be between 1 and 200 characters')
    
    if 'price' not in data:
        errors.append('price is required')
    elif not isinstance(data['price'], (int, float)) or data['price'] < 0:
        errors.append('price must be a non-negative number')
    
    # Optional fields validation
    if 'stock' in data:
        if not isinstance(data['stock'], int) or data['stock'] < 0:
            errors.append('stock must be a non-negative integer')
    
    if 'category' in data and data['category']:
        if len(data['category']) > 100:
            errors.append('category must be at most 100 characters')
    
    return errors

def validate_email(email):
    """Basic email validation"""
    if not email:
        return False
    if '@' not in email or '.' not in email:
        return False
    if len(email) > 120:
        return False
    return True

def validate_password(password):
    """Basic password validation"""
    if not password:
        return False, 'Password is required'
    if len(password) < 8:
        return False, 'Password must be at least 8 characters'
    if len(password) > 128:
        return False, 'Password must be at most 128 characters'
    return True, None
