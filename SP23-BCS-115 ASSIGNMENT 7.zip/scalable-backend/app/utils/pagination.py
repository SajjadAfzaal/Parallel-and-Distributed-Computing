"""
Pagination Utility
Efficient pagination for large datasets
"""

from flask import current_app

def paginate_query(query, page=1, per_page=20):
    """
    Paginate a SQLAlchemy query efficiently
    
    Args:
        query: SQLAlchemy query object
        page: Page number (1-indexed)
        per_page: Items per page
    
    Returns:
        dict with items and pagination metadata
    """
    # Enforce limits
    max_per_page = current_app.config.get('MAX_PAGE_SIZE', 100)
    per_page = min(per_page, max_per_page)
    per_page = max(per_page, 1)
    page = max(page, 1)
    
    # Execute paginated query
    pagination = query.paginate(
        page=page,
        per_page=per_page,
        error_out=False
    )
    
    return {
        'items': [item.to_dict() for item in pagination.items],
        'pagination': {
            'page': pagination.page,
            'per_page': pagination.per_page,
            'total_items': pagination.total,
            'total_pages': pagination.pages,
            'has_next': pagination.has_next,
            'has_prev': pagination.has_prev,
            'next_page': pagination.next_num if pagination.has_next else None,
            'prev_page': pagination.prev_num if pagination.has_prev else None
        }
    }
